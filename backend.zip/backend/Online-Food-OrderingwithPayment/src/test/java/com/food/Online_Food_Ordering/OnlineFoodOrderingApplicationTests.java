package com.food.Online_Food_Ordering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineFoodOrderingApplicationTests {

	@Test
	void contextLoads() {
	}

}
