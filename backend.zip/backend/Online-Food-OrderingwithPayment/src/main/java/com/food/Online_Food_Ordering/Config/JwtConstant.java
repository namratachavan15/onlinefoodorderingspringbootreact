package com.food.Online_Food_Ordering.Config;

public class JwtConstant {

    public static final String SECRET_KEY="gdeiuedggeihhiofewisofrioewihfbrueejkwfrioedwshfiorews";

    public static final String JWT_HEADER="Authorization";

}
