package com.food.Online_Food_Ordering.exception;

public class OrderException extends Exception {
    public OrderException(String message) {
        super(message);
    }
}
