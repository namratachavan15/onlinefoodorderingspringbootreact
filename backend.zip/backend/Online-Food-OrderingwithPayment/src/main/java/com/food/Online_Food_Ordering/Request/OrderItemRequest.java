package com.food.Online_Food_Ordering.Request;

import java.util.List;

public class OrderItemRequest {
    private Long foodId;
    private int quantity;
    private List<String> ingredients;  // Assuming ingredients are strings, adjust if necessary
    private Long totalPrice;

    // Getters and setters
    public Long getFoodId() {
        return foodId;
    }

    public void setFoodId(Long foodId) {
        this.foodId = foodId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }

    public Long getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Long totalPrice) {
        this.totalPrice = totalPrice;
    }
}
