package com.food.Online_Food_Ordering.Service;

import com.food.Online_Food_Ordering.Response.PaymentResponse;
import com.food.Online_Food_Ordering.model.Order;
import com.stripe.exception.StripeException;
import lombok.Data;
import org.springframework.data.jpa.repository.JpaRepository;

@Data
public interface PaymentService{
    public PaymentResponse createPaymentLink(Order order) throws StripeException;

}
