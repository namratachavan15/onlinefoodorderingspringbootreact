package com.food.Online_Food_Ordering.model;

public enum USER_ROLE {
    ROLE_CUSTOMER,

    ROLE_RESTAURANT_OWNER,

    ROLE_ADMIN
}
